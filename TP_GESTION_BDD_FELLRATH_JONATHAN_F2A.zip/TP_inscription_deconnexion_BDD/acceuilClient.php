<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8'/>
        <title>Connexion</title>
        <link rel="stylesheet" href="style-index.css?refresh=<?php echo rand(5,15) ?>" /> <!-- petite astuce pour recharder tout le temps le css -->
    </head>
    <body>
		<a href="Controller/deconnexion.php">Deconnexion</a>
		<form action='acceuilClient.php' method='POST'>
			<table>
				<tr>
					<th>
						Numero produit
					</th>
					<th>
						Description
					</th>
					<th>
						PUHT
					</th>
				</tr>
				
				<?php
					include_once "Controller/achatClient.php";
				?>
				
				<tr>
					<td colspan="5">
						<input type='submit' value ='Acheter' />
					</td>
				</tr>
			</table>
		</form>
	</body>
</html>

