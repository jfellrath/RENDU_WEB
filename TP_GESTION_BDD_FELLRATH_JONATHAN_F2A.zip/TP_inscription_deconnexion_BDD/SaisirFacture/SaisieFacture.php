<?php
	session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8'/>
        <title>AcheterProduit</title>
        <link type="text/css" rel="stylesheet" href="styleSaisie.css" />
    </head>
    <body>
	<?php
		if(isset($_SESSION['mail'])){
		?>
			<header>
				<table>
					<tr>
						<td>

							<!-- logo du site -->
							<img alt="logo" src="../mysql.png" />
							<a href="../index.php" />Retourner à l'acceuil</a>

						</td>
						<td>
						</td>
						<td>
							<!-- L'adresse mail de l'utilisateur -->
							<?php echo htmlspecialchars($_SESSION['mail']); ?>
							<!-- Lien vers deconnexion -->
							<br/><a href='../Controller/deconnexion.php'>Deconnexion</a>
						</td>
					</tr>
					<tr>
						<!-- Menu de navigation -->
						<td class='nav'>
							<a href="../Client/Client.php">CLIENT</a>
						</td>
						<td class='nav'>
							<a href="../Facture/Facture.php">FACTURES</a>
						</td>
						<td class='nav'>
							<a href="Produit.php">PRODUITS</a>
						</td>
					</tr>
				</table>
			</header>
					
		<?php
			include_once "ControleAffichage.php";
		}else{
			header('Location: ../index.php');
		}
	?>
	</body>
</html>