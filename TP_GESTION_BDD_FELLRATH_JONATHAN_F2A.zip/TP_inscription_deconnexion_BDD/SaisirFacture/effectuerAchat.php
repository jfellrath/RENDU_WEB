<?php
	session_start();
	
	if(isset($_SESSION['mail'])){
	
		if(isset($_POST['acheter'])){
				
			if(isset($_POST['numeroProduit']) and isset($_POST['quantite'])){
				
				// Cennexion à la base de donnée
				try{
					$bdd = new PDO('mysql:host=localhost;dbname=FACTURE','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
				}catch (Exception $e){
					die('Erreur : ' . $e->getMessage());
				}
								

				$bdd->exec("INSERT INTO facture(NumClient,DateFacture)
							(
								SELECT NumClient,CURDATE()
								FROM client
								WHERE AdresseMail = '".$_SESSION['mail']."'
							)");

				$i=0;
				for($i=0;$i<count($_POST["numeroProduit"]);$i++){	

					$reponse = $bdd->query("SELECT MAX(NumFacture) as numFacture from facture,client 
														WHERE client.NumClient = facture.NumClient 
														AND client.AdresseMail = '".$_SESSION['mail']."'");

					$numeroFacture = $reponse->fetch();
										
					$reponse->closeCursor();
					
					if($_POST['quantite'] != 0){						
						$reponse = $bdd->prepare('INSERT INTO d_facture(NumFacture,NumProduit,Quantite)
																			VALUES(:numFacture,:numProduit,:quantite)');

						$reponse->execute(array('numFacture' => $numeroFacture['numFacture'],
																	'numProduit' => $_POST['numeroProduit'][$i],
																	'quantite' => $_POST['quantite'][$i]));
															
						$reponse->closeCursor();
					}
				}
			
				header('Location: SaisieFacture.php?ok');
			}else{
				header('Location: SaisieFacture.php?err=1'); // Séléctionner au moins 1 client et une quantitée.
			}

		}
	}else{
		header('Location: ../index.php');
	}
?>