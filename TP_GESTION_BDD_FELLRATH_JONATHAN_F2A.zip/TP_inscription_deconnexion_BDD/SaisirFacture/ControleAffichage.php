	<form action='effectuerAchat' method='POST'>
		<table class='tableauProduit'>  
			<tr>
				<th style="padding:5px">ID</th>
				<th>Description</th>
				<th>PUHT</th>
			</tr>
		
	<?php

	// Cennexion à la base de donnée
    try{
        $bdd = new PDO('mysql:host=localhost;dbname=FACTURE','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
    }catch (Exception $e){
        die('Erreur : ' . $e->getMessage());
    }
	
	$reponse = $bdd->query("SELECT * FROM produits");

	$id = 1; 

	while($res = $reponse->fetch()){
				
		echo "<tr>
				<td>".$id."</td>
				<td>".htmlspecialchars($res["Des"])."</td>
				<td>".htmlspecialchars($res["PUHT"])."</td>
				<td>
						<input type='checkbox' value=".$res["NumProduit"]." name='numeroProduit[]' />
						<input type='number' name='quantite[]' value='0' min='0' />
				</td>
			</tr>";	
			$id+=1;
	}
	$reponse->closeCursor();
	
	?>
	
			<tr>
				<td colspan = '3' style='border-top:1px solid black;text-align:center'>
						<input type='submit' name='acheter' />

				</td>
			</tr>
		</table>
	</form>
