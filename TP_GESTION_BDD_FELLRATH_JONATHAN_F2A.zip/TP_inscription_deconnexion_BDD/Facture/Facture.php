<?php
	session_start();
	
?>





<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8'/>
		<link rel="stylesheet" type='text/css' href="styleFacture.css" media='screen' />
		<link rel="stylesheet" type="text/css" href="imprimante.css" media="print" />
        <title>Gestion Factures</title>
    </head>
    <body>
		<?php
			// Si la session de gérant existe
			if(isset($_SESSION["mail"])){
			?>
				<header class='imprimer'>
					<table style='margin: auto'>
						<tr>
							<td>

								<!-- logo du site -->
								<img alt="logo" src="../mysql.png" />
								<a href="../index.php" />Retourner à l'acceuil</a>

							</td>
							<td>
							</td>
							<td>
								<!-- L'adresse mail de l'utilisateur -->
								<?php echo htmlspecialchars($_SESSION['mail']); ?>
								<!-- Lien vers deconnexion -->
								<br/><a href='../Controller/deconnexion.php'>Deconnexion</a>
							</td>
						</tr>
						<tr>
							<!-- Menu de navigation -->
							<td class='nav'>
								<a href="../Client/Client.php">CLIENT</a>
							</td>
							<td class='nav'>
								<a href="/">FACTURES</a>
							</td>
							<td class='nav'>
								<a href="../Produit/Produit.php">PRODUITS</a>
							</td>
						</tr>
					</table>
				</header>
				
			<?php
				include_once "ControleFacture.php";
			}else{
				header('Location: ../index.php');
			}
		?>
	</body>
</html>