﻿<?php
    
		try{
			$bdd = new PDO('mysql:host=localhost;dbname=FACTURE','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
		}catch (Exception $e){
			die('Erreur : ' . $e->getMessage());
		}
			
		$reponse = $bdd->query("SELECT * FROM facture");
		$factures = $reponse->fetchAll();
		$reponse->closeCursor();   


?>
		<table style="border-collapse: collapse; margin: auto; margin-top: 20px;" class='imprimer'">  
			<tr>
				<th style='padding: 10px; border: 1px solid black'>ID</th>
				<th style='padding: 10px; border: 1px solid black'>Numero de facture</th>
				<th style='padding: 10px; border: 1px solid black'>Date</th>
				<th style='padding: 10px; border: 1px solid black'>Numero de Client</th>
			</tr>
<?php
		$id = 1; // Gestion de l'id tableau 
		foreach($factures as $facture){
			echo "<tr>
					<td style='border-right:1px solid black;border-left:1px solid black'>".$id."</td>
					<td style='border-right:1px solid black'>".htmlspecialchars($facture["NumFacture"])."</td>
					<td style='border-right:1px solid black'>".htmlspecialchars($facture["DateFacture"])."</td>
					<td style='border-right:1px solid black'>".htmlspecialchars($facture["NumClient"])."</td>
					<td><form action='Facture.php' method='POST'>
							<input type='radio' value=".$facture["NumFacture"]." name='numeroDFacture' />
							<input type='submit' value ='Afficher le détail' name='afficherDetail' />
						</form>
					</td>
				</tr>";		
			$id+=1;
		}
		
?>			<!-- cette ligne factice permet de fermet le tableau pour le rendu visuel -->
			<tr>
				<td colspan='4' style='border-top:1px solid black'></td>
			</tr>
		</table> 
		
<?php
		
		if(isset($_POST['afficherDetail'])){
			if(isset($_POST["numeroDFacture"])){ 
				// Lis tous les produits d'une facture	
				$reponse = $bdd->query("SELECT produits.NumProduit,Des,PUHT,Quantite
											FROM produits
											INNER JOIN d_facture
											ON produits.NumProduit = d_facture.NumProduit
											INNER JOIN facture
											ON facture.NumFacture = d_facture.NumFacture
											WHERE facture.NumFacture = ".$_POST["numeroDFacture"]);
											
				$details = $reponse->fetchAll();
				$reponse->closeCursor();   

			
				// Lis le client d'une facture.
				$reponse = $bdd->query("SELECT *,NumFacture,DateFacture
											FROM client
											INNER JOIN facture
											ON client.NumClient = facture.NumClient
											AND facture.NumFacture = ".$_POST["numeroDFacture"]);
				$clients = $reponse->fetch();
				$reponse->closeCursor();   
				
				// Lis le prix total d'ne facture.
				$reponse = $bdd->query("SELECT SUM(PUHT * d_facture.Quantite) as prix
											FROM produits
											INNER JOIN d_facture
											ON produits.NumProduit = d_facture.NumProduit
											INNER JOIN facture
											ON facture.NumFacture = d_facture.NumFacture
											WHERE facture.NumFacture = ".$_POST["numeroDFacture"]);
											
				$prixTotal = $reponse->fetch();
				$reponse->closeCursor();   



?>
			<table class='detailFacture'>
				<tr>
					<td colspan='3' style='width:800px'>
						<h3 style='margin:0px;padding:0px;'>Numero de facture: <?php echo htmlspecialchars($clients["NumFacture"]); ?> </h3><br/>
					</td>
				</tr>
				<tr>
					<td colspan='3'>
						Le: <?php echo $clients["DateFacture"]; ?>
					</td>
				</tr>
				<tr>
					<td colspan='2'>
							
					</td>
					<td style='text-align: center'>
						<?php
							echo htmlspecialchars($clients["NomClient"])."<br/>".
								htmlspecialchars($clients["PrenomClient"])."<br/>".
								htmlspecialchars($clients["AdresseMail"])."<br/>".
								htmlspecialchars($clients["AdresseClient"])."<br/>".
								htmlspecialchars($clients["Cp"])."<br/>".
								htmlspecialchars($clients["VilleClient"])."<br/>".
								htmlspecialchars($clients["PaysClient"]);
						?>
					</td>
				</tr>
				<tr>
				
				</tr>

				<tr>
					<td colspan='3'>
					</td>

				</tr>
				<tr>
					<th style='border-right: 1px solid black'>
						Description:
					</th>
					<th style='border-right: 1px solid black'>
						Quantite:
					</th>
					<th>
						PUHT:
					</th>
				</tr>
				
				
				<?php
					foreach($details as $detail){
						echo "<tr>
								<td style='border-right: 1px solid black'>
									".htmlspecialchars($detail["Des"])."
								</td>
								<td style='border-right: 1px solid black'>
									".htmlspecialchars($detail["Quantite"])."
								</td>
								<td>
									".htmlspecialchars($detail["PUHT"])."
								</td>
							</tr>";
					}
				?>
				
				<tr>
					<td colspan='3'></td>
				</tr>
				<tr>
					<td colspan='2'>
					</td>
					<td style='text-align:right'>
						<?php echo "PRIX TOTAL HT: ".$prixTotal['prix']."€"; ?>
					</td>
				</tr>
			</table>
		<?php
			}else{
				?>
					<script type="text/javascript">
	   
						alert("Merci de séléctionner une facture.");
	   
					</script>
					<noscript>
						<p>
							<?php echo "Merci de séléctionner une facture"; ?>
						</p>
					</noscript>
				<?php
			}
		}
		
?>