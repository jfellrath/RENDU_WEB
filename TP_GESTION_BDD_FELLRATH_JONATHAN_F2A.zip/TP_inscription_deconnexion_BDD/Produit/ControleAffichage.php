<?php
// Controller Client.

	// Cennexion à la base de donnée
    try{
        $bdd = new PDO('mysql:host=localhost;dbname=FACTURE','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
    }catch (Exception $e){
        die('Erreur : ' . $e->getMessage());
    }
	
	// Séléction des clients
	$reponse = $bdd->query("SELECT * FROM produits"); // NumProduit Des PUHT
	$produits = $reponse->fetchAll();
	$reponse->closeCursor(); 

	$id = 1; // Gestion de l'id tableau 
	
?>
	<table class='tableauProduit'>  
		<tr>
			<th style="padding:5px">ID</th>
			<th>Description</th>
			<th>PUHT</th>

		</tr>
<?php
	foreach($produits as $produit){
		echo "<tr>
				<td style='border-left:1px solid black;;border-right:1px solid black'>".$id."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($produit["Des"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($produit["PUHT"])."</td>

				<td><form action='ModifierProduit.php' method='POST'>
						<input type='radio' value=".$produit['NumProduit']." name='numeroProduit' />
						<input type='submit' value ='Modifier' name='modifierProduit' />
					</form>
					<form action='ControleSuppProduit.php' method='POST'>
						<input type='radio' value=".$produit["NumProduit"]." name='numeroProduit' />
						<input type='submit' value ='Supprimer' name='supprimerProduit' />
					</form>
				</td>
			</tr>";	
		$id+=1;
	}
?>
		<tr>
			<td colspan = '3' style='border-top:1px solid black;text-align:center'>
				<form action='AjouterProduit.php' method="POST">
					<input type='submit' value='Ajouter un produit' name='ajouterProduit' />
				</form>
			</td>
		</tr>
	</table>