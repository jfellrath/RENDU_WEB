<?php
	session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8'/>
		<link rel="stylesheet" href="styleProduit.css" />
        <title>Ajouter Produit</title>
    </head>
    <body>
		<header>
			<table>
				<tr>
					<td>

						<!-- logo du site -->
						<img alt="logo" src="../mysql.png" />
						<a href="Produit.php" />Retourner à la page précédente</a>

					</td>
					
					<td>
					
					</td>
					
					<td>
						<!-- L'adresse mail de l'utilisateur -->
						<?php echo htmlspecialchars($_SESSION['mail']); ?>
						<!-- Lien vers deconnexion -->
						<br/><a href='../Controller/deconnexion.php'>Deconnexion</a>
					</td>
				</tr>
			</table>
		</header>
		<nav>
			<h4>AJOUTER UN CLIENT</h4>
			<form action="ControleAjoutProduit.php" method="POST">
				<!-- Nom  -->
				<label>Description</label><br/>
				<input type="text" name="des" /><br/><br/>
				<!-- Prenom -->
				<label id="prenom">PUHT</label><br/>
				<input type="text" name="puht"/><br/><br/>
				<!-- Valider -->
				<input type="submit" value="Valider" name="ajouterProduit" />
			</form>
		</nav>
	</body>
</html>