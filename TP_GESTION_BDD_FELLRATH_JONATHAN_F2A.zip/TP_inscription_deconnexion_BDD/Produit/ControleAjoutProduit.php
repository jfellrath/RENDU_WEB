<?php
	// Controller Client.
	if(isset($_POST['ajouterProduit'])){

		// Cennexion à la base de donnée
		try{
			$bdd = new PDO('mysql:host=localhost;dbname=facture','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
		}catch (Exception $e){
			die('Erreur : ' . $e->getMessage());
		}
		
		// Verifie l'existence d'un profil. (Utiliser lors de l'inscription et lors de la modification d'un profil)
		// $mail c'est l'adresse mail à vérifier
		function VerifProduit($produit,$base){
		
			$reponse = $base->prepare('SELECT Upper(Des) FROM client WHERE UPPER(Des) = UPPER(?)');
			
			$reponse->execute(array($produit));
			
			$res = $reponse->fetch();
			
			$reponse->closeCursor();
			
			return $res;
		}
		
		function InsererProduit($base){
			$reponse = $base->prepare('
				INSERT INTO client(Des,PUHT) 
				VALUES(:des,:puht)');


			$reponse->execute(array('des' => $_POST['des'],
						'puht' => $_POST['puht']));
						
			$reponse->closeCursor();
		}
		

		if (isset($_POST['des']) and 
			isset($_POST['puht']) and
			!empty($_POST['des']) and 
			!empty($_POST['puht'])){ // Si les champs existe et ne sont pas vides

				// Si l'adresse mail validé par le formulaire existe déjà on l'indique
				if(!empty(VerifProduit($_POST["des"],$bdd))){

					header('Location: Produitt.php?erreur=1');
						
				}else{ // Sinon on insert le client
				
						InsererProduit($bdd);
						header('Location: Produit.php?ok=1');

				}
			}else{ //les champs sont mal remplis

				header('Location: Produit.php?erreur=2');
		
			}
	}else{
		
		header('Location: Produit.php');
		
	}
			
	
?>
