<?php
	session_start();
	
	// Controller Modif Client.
	if(isset($_POST['modifierProduit'])){
		if(isset($_SESSION['numero'])){

			// Cennexion à la base de donnée
			try{
				$bdd = new PDO('mysql:host=localhost;dbname=facture','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			}catch (Exception $e){
				die('Erreur : ' . $e->getMessage());
			}
		
			function ModifierProduit($numProduit,$base){
				$reponse = $base->prepare("UPDATE produits SET 
												Des = :des, 
												PUHT = :puht
												WHERE NumProduit = ".$numProduit);
																	
				$reponse->execute(array('des' => $_POST['des'],
							'puht' => $_POST['puht']));
								
				$reponse->closeCursor();

			}
			

			if (isset($_POST['des']) and 
				isset($_POST['puht']) and 
				!empty($_POST['des']) and 
				!empty($_POST['puht'])){ // Si les champs existe et ne sont pas vides


					ModifierProduit($_SESSION['numero'],$bdd);
					$_SESSION['numero'] = array();
					header('Location: Produit.php?ok=2');

			}else{ //les champs sont mal remplis

				header('Location: Produit.php?erreur=2');
			
			}
		}else{ // Aucun client selectionné
			header('Location: Produit.php?erreur=3');
		}
	}else{
		// Si on arrive ici sans cliquer sur modifier client
		header('Location: Produit.php');
		
	}
			
	
?>