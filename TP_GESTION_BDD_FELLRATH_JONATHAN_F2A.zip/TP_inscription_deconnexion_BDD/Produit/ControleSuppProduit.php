<?php
	
	// Controller Modif Client.
	if(isset($_POST['supprimerProduit'])){
		if(isset($_POST['numeroProduit'])){

			// Cennexion à la base de donnée
			try{
				$bdd = new PDO('mysql:host=localhost;dbname=facture','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			}catch (Exception $e){
				die('Erreur : ' . $e->getMessage());
			}
		
			$bdd->exec("DELETE FROM produits WHERE NumProduit = ".$_POST['numeroProduit']);
			header('Location: Produit.php?ok=3');


		}else{ // Aucun client selectionné
			header('Location: Produit.php?erreur=3');
		}
	}else{
		// Si on arrive ici sans cliquer sur modifier client
		header('Location: Produit.php');
		
	}
			
	
?>