<?php
	session_start();
	
	if(isset($_SESSION['mail'])){
		
		if(isset($_POST['numeroProduit'])){
			
			$_SESSION['numero'] = $_POST['numeroProduit']; // Utiliser pour envoyer vers le controleModifClient
			
			// Cennexion à la base de donnée
			try{
				$bdd = new PDO('mysql:host=localhost;dbname=FACTURE','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			}catch (Exception $e){
				die('Erreur : ' . $e->getMessage());
			}
			

			// Lire un client séléctionné par son id
			$reponse = $bdd->query("SELECT * FROM produits WHERE NumProduit = ".$_POST['numeroProduit']);
			$produit = $reponse->fetch();
			$reponse->closeCursor(); 

		?>
		<!DOCTYPE html>
		<html>
			<head>
				<meta charset='utf-8'/>
				<link type="text/css" rel="stylesheet" href="styleProduit.css" />
				<title>Modifier Produit</title>
			</head>
			<body>
				<header>
					<table>
						<tr>
							<td>
								<!-- logo du site -->
								<img alt="logo" src="../mysql.png" />
								<a href="Produit.php" />Retourner à la page précédente</a>
							</td>
							
							<td>
							
							</td>
							
							<td>
								<!-- L'adresse mail de l'utilisateur -->
								<?php echo htmlspecialchars($_SESSION['mail']); ?>
									<!-- Lien vers deconnexion -->
									<br/><a href='../Controller/deconnexion.php'>Deconnexion</a>
							</td>
						</tr>
					</table>
				</header>

				<nav>
					<h4>MODIFIER UN PRODUIT</h4>
					<form action="ControleModifProduit.php" method="POST">
						<!-- Nom  -->
						<label>Description</label><br/>
						<input type="text" name="des" value="<?php echo $produit['Des'] ?>" /><br/><br/> 
						<!-- Prenom -->
						<label>PUHT</label><br/>
						<input type="text" name="puht" value="<?php echo $produit['PUHT'] ?>"/><br/><br/>

						<!-- Valider -->
						<input type="submit" value="Valider" name="modifierProduit" />
					</form>
				</nav>		
			</body>
		</html>
		<?php
		}else{
			header('Location: Produit.php?erreur=3');
		}
	}else{
		header('Location: ../index.php');
	}
?>