<?php
	session_start();
	

	// Verification du formulaire.
	if (isset($_POST['nom']) and 
		isset($_POST['prenom']) and 
		isset($_POST['mdp']) and 
		isset($_POST['mail']) and 
		isset($_POST['adresse']) and 
		isset($_POST['ville']) and
		isset($_POST['pays']) and 
		isset($_POST['cp']) and 
		!empty($_POST['nom']) and 
		!empty($_POST['prenom']) and 
		!empty($_POST['mail']) and 
		!empty($_POST['mdp']) and 
		!empty($_POST['adresse']) and 
		!empty($_POST['ville']) and 
		!empty($_POST['pays']) and 
		!empty($_POST['cp'])){ // Si les champs sont pas vide
							
			// Connexion base de données
			try{
				$bdd = new PDO('mysql:host=localhost;dbname=FACTURE','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			}catch (Exception $e){
				die('Erreur : ' . $e->getMessage());
			}
			
			$reponse = $bdd->prepare('SELECT AdresseMail FROM client WHERE AdresseMail = ?');
		
			$reponse->execute(array($_POST["mail"]));
		
			$res = $reponse->fetch();
		
			$reponse->closeCursor();

					

			// Si l'adresse mail validé par le formulaire existe déjà on fait rien
			if(!empty($res["AdresseMail"])){
				header('Location: ../index.php?err=3'); // Cette adresse mail n'est pas disponible.
						
			}else{ // Sinon on insert le client
				$reponse = $bdd->prepare('
					INSERT INTO client(NomClient,PrenomClient,MotDePasseClient,AdresseMail,AdresseClient,Cp,VilleClient,PaysClient) 
					VALUES(:nom,:prenom,:mdp,:mail,:adresse,:cp,:ville,:pays)');


				$reponse->execute(array('nom' => $_POST['nom'],
					'prenom' => $_POST['prenom'],
					'mdp' => password_hash($_POST['mdp'],PASSWORD_DEFAULT),
					'mail' => $_POST['mail'],
					'adresse' => $_POST['adresse'],
					'cp' => $_POST['cp'],
					'ville' => $_POST['ville'],
					'pays' => $_POST['pays']));
					
				$reponse->closeCursor();
				
				header('Location: ../index.php?ok');
			}
	}else{
		header('Location: ../index.php?err=1'); // Si les champs sont vide
				
	}
		
	
?>





















