<?php
	include_once "../Modele/BaseDeDonnees.php";
	include_once "../Modele/Produit.php";
	
	// On se connecte à la bdd et on affiche les produits
	$base = new Base;
	$base->ConnexionBdd(); 
		
	$produits = $base->LireProduits();
	
	$id = 1; // Index tu tableau des produits
	foreach($produits as $produit){
			
		echo "<tr>
				<td style='border-right:1px solid black;border-left:1px solid black'>".$id."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($produit["Des"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($produit["PUHT"])."</td>
				<td>
					<form action='vue_produit.php' method='POST'>
						<input type='radio' value=".$produit["NumProduit"]." name='numeroProduit' />
						<input type='submit' value ='Modifier' name='modifier' />
					</form>
				</td>
			</tr>";	
			
		$id+=1;
	}
	
		// Même principe que pour le client.
		if(isset($_POST["numeroProduit"])){ // Validé par le formulaire au-dessus.
			$produit = $base->LireProduit($_POST["numeroProduit"]); // Utilisé pour l'autocompletion du formulaire
			$_SESSION["numeroProduit"] = $produit["NumProduit"]; // On créé une session sinon en validant le formulaire de modification on pert l'information.
		}
		
		// Ajouter un Produit
		if(isset($_POST["AjouterProduit"])){
			if (isset($_POST['des']) and 
				isset($_POST['puht']) and 
				!empty($_POST['des']) and 
				!empty($_POST['puht'])){ // Si les champs existe et ne sont pas vides

					// Creation du Produit
					$Produit = new Produit($_POST['des'],$_POST['puht']);
	
					// Si le produit n'existe pas déjà
					if(!empty($base->VerifProduit($_POST["des"]))){

						echo "<script type='text/javascript'>
								
								alert('Vous avez déjâ un produit nommé \'".$_POST['des']."\'. Peut être souhaiteriez vous le modifier ?');
								
							</script>" 
						?>
							<noscript>
								<p>
									<?php echo "Vous avez déjâ un produit nommé ".$_POST['des'].". Peut être souhaiteriez vous le modifier ?"; ?>
								</p>
							</noscript>
						<?php
						
					}else{ // Sinon on insert le produit
						$base->InsererProduit($Produit);
						
						// Vide l'information chercher en base.
						$produit = array();
						$_SESSION['numeroProduit'] = array();
					
						// Actualise la page
						header('Location: vue_produit.php?refresh');
						
					}
			}else{ //les champs sont mal remplis
				?>
					<script type='text/javascript'>
					
						alert('Merci de remplir tous les champs.');
						
					</script>
					
					<noscript>
						<p>
							<?php echo "Merci de remplir tous les champs."; ?>
						</p>
					</noscript>
				<?php
			}
		// Modifier un produit
		}else if(isset($_POST["modifierProduit"])){ // Validée par le formulaire de modification
			if (isset($_POST['des']) and 
				isset($_POST['puht']) and 
				!empty($_POST['des']) and 
				!empty($_POST['puht'])){ // Si les champs existe et ne sont pas vides
					
					// Creation du Produit
					$Produit = new Produit($_POST['des'],$_POST['puht']);
						
					// Modification du produit
					$base->ModifierProduit($Produit,$_SESSION["numeroProduit"]);
						
					// Vide les informations chercher en base.
					$_SESSION["numeroProduit"] = array();
					$produit = array();
					
					header('Location: vue_produit.php?refresh');
	
				}else{
					//les champs sont mal remplis
					?>
						<script type='text/javascript'>
					
							alert('Merci de remplir tous les champs.');
						
						</script>
					
						<noscript>
							<p>
								<?php echo "Merci de remplir tous les champs."; ?>
							</p>
						</noscript>
					<?php	
				}
		}
			
?>
