<?php
	session_start();
		if(isset($_SESSION['mail'])){
			include_once "Modele/BaseDeDonnees.php";
			$base = new Base;
			$base->ConnexionBdd(); 
			
			$base->afficherProduitClient();
			
			if(isset($_POST['numeroProduit']) and isset($_POST['quantite'])){
				$base->effectuerAchat($_SESSION['mail']);
				$i=0;
				for($i=0;$i<count($_POST["numeroProduit"]);$i++){
					$base->insererDetail($_POST['numeroProduit'][$i],$_SESSION['mail'],$_POST['quantite'][$i]);
				}
			}else{
				echo "Vous devez choisir un produit";
			}
		}else{
			header('Location: index.php');
		}
		?>