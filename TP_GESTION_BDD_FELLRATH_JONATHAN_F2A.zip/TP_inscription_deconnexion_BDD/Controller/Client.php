<?php
// Controller Client.

	// On inclus le modèles client et base de données
	include_once "../Modele/Client.php";
	include_once "../Modele/BaseDeDonnees.php";
	
	// On se connecte à la bdd et on affiche les clients.
	$base = new Base;
	$base->ConnexionBdd(); 

	$clients = $base->LireClients(); // Lecture des clients
	$id = 1; // Gestion de l'id tableau 
	foreach($clients as $client){
		echo "<tr>
				<td style='border-left:1px solid black;;border-right:1px solid black'>".$id."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["NomClient"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["PrenomClient"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["MotDePasseClient"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["AdresseMail"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["AdresseClient"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["Cp"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["VilleClient"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["PaysClient"])."</td>
				<td><form action='vue_client.php' method='POST'>
						<input type='radio' value=".$client["NumClient"]." name='numeroClient' id='client".$id."' />
						<input type='submit' value ='Modifier' name='modifier' />
					</form>
					<form action='vue_client.php' method='POST'>
						<input type='radio' value=".$client["NumClient"]." name='numeroClientSupp' id='client".$id."' />
						<input type='submit' value ='Supprimer' name='supprimer' />
					</form>
				</td>
			</tr>";	
		$id+=1;
	}

		// Quant on clique sur modifier le formulaire envoie sur cette meme page l'id en base du client à modifier.
		// Le formulaire de modification de la page vue_client renvoie sur cette même page, du coup l'id du client n'existe plus puisque ce n'est
		//	plus le formulaire modifier qui est enoyé.
		// Donc quand on clique sur modifier je créé une variable de session qui contient l'id pour que quand on valide le formulaire de modification
		//  on a toujours la clé actif.
		if(isset($_POST["numeroClient"])){ // Validé par le formulaire juste au dessus
			$client = $base->LireClient($_POST["numeroClient"]); // Utilisé pour l'autocompletion du formulaire
			$_SESSION["numeroClient"] = $client["NumClient"];
		}
		

		
		// Ajouter un client
		if(isset($_POST["ajouterClient"])){
			if (isset($_POST['nom']) and 
				isset($_POST['prenom']) and 
				isset($_POST['mdp']) and 
				isset($_POST['mail']) and 
				isset($_POST['adresse']) and 
				isset($_POST['ville']) and
				isset($_POST['pays']) and 
				isset($_POST['cp']) and
				!empty($_POST['nom']) and 
				!empty($_POST['prenom']) and 
				!empty($_POST['mail']) and 
				!empty($_POST['mdp']) and 
				!empty($_POST['adresse']) and 
				!empty($_POST['ville']) and 
				!empty($_POST['pays']) and 
				!empty($_POST['cp'])){ // Si les champs existe et ne sont pas vides

					// Creation du client
					$Client = new Client("",$_POST['nom'],$_POST['prenom'],$_POST['mail'],$_POST['mdp'],$_POST['adresse'],$_POST['ville'],$_POST['pays'],$_POST['cp']);

					// Si l'adresse mail validé par le formulaire existe déjà on l'indique
					if(!empty($base->VerifMail($_POST["mail"]))){
						?>
							<script type="text/javascript">
   
								alert("Cette adresse mail existe déjà.");
   
							</script>
							<noscript>
								<p>
									<?php echo "Cette adresse mail existe déjà."; ?>
								</p>
							</noscript>
						<?php
					}else{ // Sinon on insert le client
						$base->InsererClient($Client);
						?>
							<script type="text/javascript">
   
								alert("Le nouveau client à correctement été ajouté en base. Actualiser la page pour voir les modifications.");
   
							</script>
							<noscript>
								<p>
									<?php echo "Le nouveau client à correctement été ajouté en base. <a href='vue_client.php'>Actualiser la page pour voir les modifications.</a>"; ?>
								</p>
							</noscript>
						<?php

					}
			}else{ //les champs sont mal remplis
				?>
					<script type="text/javascript">
   
						alert("Merci de remplir tous les champs.");
   
					</script>
					<noscript>
						<p>
							<?php echo "Merci de remplir tous les champs"; ?>
						</p>
					</noscript>
				<?php
				
			}
			
			
		// Modifier un client
		}else if(isset($_POST["modifierClient"])){ // Validée par le formulaire de modification
			if (isset($_POST['nom']) and 
				isset($_POST['prenom']) and 
				isset($_POST['mail']) and 
				isset($_POST['adresse']) and 
				isset($_POST['ville']) and
				isset($_POST['pays']) and 
				isset($_POST['cp']) and
				!empty($_POST['nom']) and 
				!empty($_POST['prenom']) and 
				!empty($_POST['mail']) and 
				!empty($_POST['adresse']) and 
				!empty($_POST['ville']) and 
				!empty($_POST['pays']) and 
				!empty($_POST['cp'])){ // Si les champs existe et ne sont pas vides
					
						// Creation du client
						$Client = new Client("",$_POST['nom'],$_POST['prenom'],$_POST['mail'],'',$_POST['adresse'],$_POST['ville'],$_POST['pays'],$_POST['cp']);
						
						// Modification du client
						$base->ModifierClient($Client,$_SESSION["numeroClient"]);
						
						// Vide le numero de client à modifier
						$_SESSION["numeroClient"] = array();
						// Vide l'information chercher en base
						$client = array();
						
						// Actualise la page.
						header('Location: vue_client.php?refresh');
			}else{
				?>
					<script type="text/javascript">
   
						alert("Merci de remplir tous les champs.");
   
					</script>
					<noscript>
						<p>
							<?php echo "Merci de remplir tous les champs."; ?>
						</p>
					</noscript>
							
				<?php
				//les champs sont mal remplis
				
			}
		}		
?>
	