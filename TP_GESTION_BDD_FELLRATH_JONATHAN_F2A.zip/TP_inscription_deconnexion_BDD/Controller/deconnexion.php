<?php
		session_start();
		
		if(isset($_SESSION['numero'])){
			$_SESSION['numero'] = array();
		}
		session_destroy(); 
		header("Location: ../index.php");
?>