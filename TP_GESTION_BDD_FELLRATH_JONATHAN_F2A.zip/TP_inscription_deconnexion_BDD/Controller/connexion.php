<?php
	session_start();


	if(isset($_POST['mdp']) and isset($_POST['mail'])){ // Si le formulaire est validé
				
			if(!empty($_POST['mail']) and !empty($_POST['mdp'])){ // Si les champs sont pas vide
					
				

				// Connexion base de données
				try{
					$bdd = new PDO('mysql:host=localhost;dbname=FACTURE','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
				}catch (Exception $e){
					die('Erreur : ' . $e->getMessage());
				}
					
				// Si les informations sont correctes
				$reponse = $bdd->prepare('SELECT AdresseMail,MotDePasseClient FROM client WHERE AdresseMail = ?');
		
				$reponse->execute(array($_POST['mail']));
		
				$res = $reponse->fetch();
				
				$reponse->closeCursor();
		
				if(!empty($res['AdresseMail'])){ // Si l'adresse mail existe
					if(password_verify($_POST['mdp'],$res['MotDePasseClient'])){ // Si le mot de passe est bon
						$_SESSION['mail'] = $_POST['mail'];
						header('Location: ../index.php');
					}else{
						header('Location: ../index.php?err=2'); // Si c'est pas le bon mdp.
					}
				}else{
					header('Location: ../index.php?err=2'); // Si c'est pas la bonne adresse mail
				}
			}else{
				header('Location: ../index.php?err=1'); // si les champs son vide err = 1
			}
	}
	

?>