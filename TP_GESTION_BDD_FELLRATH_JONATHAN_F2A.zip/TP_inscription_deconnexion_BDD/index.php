<?php
    session_start();
	
	if(isset($_GET['err']) and $_GET['err'] == 1){
	?>
		<script type="text/javascript">
   
			alert("Merci de remplir tous les champs");
   
		</script>
		<noscript>
			<p>
				<?php
						echo "Merci de remplir tous les champs";
				?>
			</p>
		</noscript>
	<?php
	}else if(isset($_GET['err']) and $_GET['err'] == 2){
	?>
		<script type="text/javascript">
   
			alert("Merci de rentrer une adresse mail ou un mot de passe valide.");
   
		</script>
		<noscript>
			<p>
				<?php
						echo "Merci de rentrer une adresse mail ou un mot de passe valide.";
				?>
			</p>
		</noscript>
	<?php
	}else if(isset($_GET['err']) and $_GET['err'] == 3){
	?>
		<script type="text/javascript">
   
			alert("Cette adresse mail n'est pas disponible.");
   
		</script>
		<noscript>
			<p>
				<?php
						echo "Cette adresse mail n'est pas disponible.";
				?>
			</p>
		</noscript>
	<?php
	}else if(isset($_GET['ok'])){
	?>
		<script type="text/javascript">
   
			alert("Vous êtes enregistré. Vous pouvez vous connecter à l'aide de votre adresse mail et de votre mot de passe.");
   
		</script>
		<noscript>
			<p>
				<?php
						echo "Vous êtes enregistré. Vous pouvez vous connecter à l'aide de votre adresse mail et de votre mot de passe.";
				?>
			</p>
		</noscript>
	<?php
	}
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8'/>
        <title>Connexion</title>
        <link rel="stylesheet" href="style-index.css" /> <!-- petite astuce pour recharder tout le temps le css -->
    </head>
    <body>
		<header>
			<table style="margin:auto">
				<tr>
					<td>
						<!-- logo du site -->
						<img alt="logo" src="mysql.png" />
					</td>
					<td>
					</td>
		<?php
			// Si la session existe, j'affiche les coordonnées de l'utilisateur
			if (isset($_SESSION['mail']) and $_SESSION['mail'] == 'fellrathjonathan@free.fr'){
			?>
				
					<td>
						<!-- L'adresse mail de l'utilisateur -->
						<?php echo htmlspecialchars($_SESSION['mail']); ?>
						<!-- Lien vers deconnexion -->
						<br/><a href='Controller/deconnexion.php'>Deconnexion</a>
					</td>
				</tr>
				<tr>
					<!-- Menu de navigation -->
					<td class='nav'>
						<a href="Client/Client.php">CLIENT</a>
					</td>
					<td class='nav'>
						<a href="Facture/Facture.php">FACTURES</a>
					</td>
					<td class='nav'>
						<a href="Produit/Produit.php">PRODUITS</a>
					</td>
				</tr>
				<tr>
					<td colspan='3' class='nav'>
						<!--<a href="SaisirFacture/saisieFacture.php">ACHETER PRODUITS</a>-->
					</td>
				</tr>
			</table>
		</header>
			<?php
			}else{
			?>
					<td>
						Hors ligne
					</td>
				</tr>
			</table>
		</header>
				<!-- formulaire de connexion -->
				<section>
					<form action="Controller/connexion.php" method="POST">
						<table>
							<tr>
								<td colspan="3">
									<h3>Je me connecte >></h3>
								</td>
							</tr>
							<tr>
								<td>
									<label id="mail">Adresse mail</label><br />
									<input type="text" name="mail"/><br/>
									<label id="mdp">Mot de passe</label><br/>
									<input type="password" name="mdp"/>
								</td>
							</tr>
							<tr>
								<td colspan="3">
									<input type="submit" value="Connexion" name="Connexion" />
								</td>
							</tr>
						</table>
					</form>
				</section>
				<!-- formulaire d'inscription -->
				<section>
					<form action="Controller/inscription.php" method="POST">
						<table>
							<tr>
								<td>
									<h3>Je m'inscris >></h3>
								</td>
							</tr>
							<tr>
								<td>
									<!-- Nom  -->
									<label id="nom">Nom</label><br/>
									<input type="text" name="nom"/>
								</td>
							</tr>
							<tr>
								<td>
									<!-- Prenom -->
									<label id="prenom">Prenom</label><br/>
									<input type="text" name="prenom"/>
								</td>
							</tr>
							<tr>
								<td>
									<!-- Mot de passe -->
									<label id="mdp">Mot de passe</label><br/>
									<input type="password" name="mdp"/>
								</td>
							</tr>
							<tr>
								<td>
									<!-- Adresse Mail -->
									<label id="mail">Adresse mail</label><br/>
									<input type="text" name="mail"/>
								</td>
							</tr>
							<tr>
								<td>
									<!-- Adrresse -->
									<label id="adresse">Adresse</label><br/>
									<input type="text" name="adresse"/>
								</td>
							</tr>
							<tr>
								<td>
									<!-- Code postal -->
									<label id="cp">Code postal</label><br/>
									<input type="text" name="cp"/>
								</td>
							</tr>
							<tr>
								<td>
									<!-- Ville -->
									<label id="ville">Ville</label><br/>
									<input type="text" name="ville"/>
								</td>
							</tr>
							<tr>
								<td>
									<!-- Pays -->
									<label id="pays">Pays</label><br/>
									<input type="text" name="pays"/>
								</td>
							</tr>
							<tr>
								<td>
									<!-- Valider -->
									<input type="submit" value="Inscription" name="Inscription" />
								</td>
							</tr>
						</table>
					</form>
				</section>
			<?php
            }
        ?>
    </body>
</html>