<?php

// Modele client

	include_once "Client.php";
	include_once "Produit.php"

class Facture
{
  private $client = new Client(); 
  private $produit = new Produit(); 
  private $date;
        
        
  /*public function __construct($description,$prix){
	$this->_description = $description;
	$this->_prix = $prix;
  }*/
  
  /*public function AfficherClient(){
	echo "Nom: " . $this->_nom . "<br/>" .
		"Prenom :" . $this->_prenom . "<br/>" .
		"Adresse mail: " . $this->_adresseMail . "<br/>" .
		"Mdp: " . $this->_mdp . "<br/>" .
		"Adresse: " . $this->_adresse . "<br/>" .
		"Ville: " . $this->_ville . "<br/>" .
		"Pays: " . $this->_pays . "<br/>" .
		"Code postal: " . $this->_cp;
  }*/
  
  public function Getclient(){
	  return $this->client;
  }
  public function GetProduit(){
	  return $this->produit;
  }
  public _GetDate(){
	  
  }
  
}

?>