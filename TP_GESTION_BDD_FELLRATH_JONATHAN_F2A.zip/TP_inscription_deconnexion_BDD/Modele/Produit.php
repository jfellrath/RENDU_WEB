<?php

// Modele client

class Produit
{
  private $_description; 
  private $_prix; 
        
        
  public function __construct($description,$prix){
	$this->_description = $description;
	$this->_prix = $prix;
  }
  
  public function GetDescription(){
	  return $this->_description;
  }
  public function GetPrix(){
	  return $this->_prix;
  }
  
}

?>