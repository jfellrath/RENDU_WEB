<?php

// Modele client

class Client
{
  private $_id;
  private $_nom; 
  private $_prenom; 
  private $_adresseMail; 
  private $_mdp;
  private $_adresse;
  private $_ville;
  private $_pays;
  private $_cp;
        
        
  public function __construct($id,$nom,$prenom,$adresseMail,$mdp,$adresse,$ville,$pays,$cp){
	$this->_id = $id;
	$this->_nom = $nom;
	$this->_prenom = $prenom;
	$this->_adresseMail = $adresseMail;
	$this->_mdp = $mdp;
	$this->_adresse = $adresse;
	$this->_ville = $ville;
	$this->_pays = $pays;
	$this->_cp = $cp;
  }
  
  public function AfficherClient(){
	echo "Nom: " . $this->_nom . "<br/>" .
		"Prenom :" . $this->_prenom . "<br/>" .
		"Adresse mail: " . $this->_adresseMail . "<br/>" .
		"Mdp: " . $this->_mdp . "<br/>" .
		"Adresse: " . $this->_adresse . "<br/>" .
		"Ville: " . $this->_ville . "<br/>" .
		"Pays: " . $this->_pays . "<br/>" .
		"Code postal: " . $this->_cp;
  }
  
   public function GetId(){
	  return $this->_id;
  }
  public function GetNom(){
	  return $this->_nom;
  }
  public function GetPrenom(){
	  return $this->_prenom;
  }
  public function GetMail(){
	  return $this->_adresseMail;
  }
  public function GetMdp(){
	  return $this->_mdp;
  }
  public function GetAdresse(){
	  return $this->_adresse;
  }
  public function GetVille(){
	  return $this->_ville;
  }
  public function GetPays(){
	  return $this->_pays;
  }
  public function GetCp(){
	  return $this->_cp;
  }
}

?>