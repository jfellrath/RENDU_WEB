<?php

// Modele de base de données


class Base{
	
	private $bdd;
	private $reponse;
	private $resultat;
	public $autocompletion;

	
	// Cennexion à la base de donnée
	public function ConnexionBdd(){                
        try{
            $this->bdd = new PDO('mysql:host=localhost;dbname=FACTURE','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        }catch (Exception $e){
            die('Erreur : ' . $e->getMessage());
        }
		
	}
	
	// Supprimer un champs
	public function Supprime($id,$table,$champ){
		$reponse = $this->bdd->exec("DELETE FROM ".$table." WHERE ".$champ." = ".$id);
	}
	
	

	// Verifie l'existence d'un profil. (Utiliser lors de l'inscription et lors de la modification d'un profil)
	// $mail c'est l'adresse mail à vérifier
	public function VerifMail($mail){
	
		$reponse = $this->bdd->prepare('SELECT AdresseMail FROM client WHERE AdresseMail = ?');
		
		$reponse->execute(array($mail));
		
		$res = $reponse->fetch();
		
		$reponse->closeCursor();
		
		return $res;
	}
	
	// Verifi les informations de connexion et renvoie true si c'est bon false si c'est pas bon
	public function VerifConnexion($mail,$mdp){
		
		$reponse = $this->bdd->prepare('SELECT AdresseMail,MotDePasseClient FROM client WHERE AdresseMail = ?');
		
		$reponse->execute(array($mail));
		
		$res = $reponse->fetch();
		
		if(!empty($res['AdresseMail'])){ // Si l'adresse mail existe
                if(password_verify($mdp,$res['MotDePasseClient'])){ // Test du mot de passe
					$reponse->closeCursor();
                    return true;
                }else{
					$reponse->closeCursor();
					return false;
				}
		}else{
			$reponse->closeCursor();
			return false;
		}	
	}
	
	// Effectuer une insertion de client.
	// Utiliser pour l'inscription et pour l'ajout de client.
	public function InsererClient($client){
		$reponse = $this->bdd->prepare('
			INSERT INTO client(NomClient,PrenomClient,MotDePasseClient,AdresseMail,AdresseClient,Cp,VilleClient,PaysClient) 
			VALUES(:nom,:prenom,:mdp,:mail,:adresse,:cp,:ville,:pays)');


		$reponse->execute(array('nom' => $client->GetNom(),
					'prenom' => $client->GetPrenom(),
					'mdp' => password_hash($client->GetMdp(),PASSWORD_DEFAULT),
					'mail' => $client->GetMail(),
					'adresse' => $client->GetAdresse(),
					'cp' => $client->GetCp(),
					'ville' => $client->GetVille(),
					'pays' => $client->GetPays()));
					
		$reponse->closeCursor();
	}
	
	// Modifier un client. 
	// $client c'est les valeurs du nouveau client.
	// $numClient c'est l'index en base du client.
	public function ModifierClient($client,$numClient){
		$reponse = $this->bdd->prepare("UPDATE client SET 
														NomClient = :nom, 
														PrenomClient = :prenom,
														AdresseMail = :mail,
														AdresseClient = :adresse,
														Cp = :cp,
														VilleClient = :ville,
														PaysClient = :pays 
														WHERE NumClient = ".$numClient);
														
		$reponse->execute(array('nom' => $client->GetNom(),
					'prenom' => $client->GetPrenom(),
					'mail' => $client->GetMail(),
					'adresse' => $client->GetAdresse(),
					'cp' => $client->GetCp(),
					'ville' => $client->GetVille(),
					'pays' => $client->GetPays()));
					
		$reponse->closeCursor();

	}
	

	

	
	
	/* -- Gestion des produits -- */
	
	
	// Verifie l'existence d'un produit. 
	// $produit c'est le produit à vérifier
	public function VerifProduit($produit){
	
		$reponse = $this->bdd->prepare('SELECT UPPER(des) FROM produits WHERE UPPER(des) = UPPER(?)');
		
		$reponse->execute(array($produit));
		
		$res = $reponse->fetch();
		
		$reponse->closeCursor();
		
		return $res;
	}
	
	// Lire un produit en fonction de son id
	public function LireProduit($numeroProduit){
		$reponse = $this->bdd->query("SELECT * FROM produits WHERE NumProduit = ".$numeroProduit);
		$res = $reponse->fetch();
		$reponse->closeCursor();
		return $res;
	}
	
	// lire tous les produits
	public function LireProduits(){
		$reponse = $this->bdd->query("SELECT * FROM produits");
		
		$res = $reponse->fetchAll();
		
		$reponse->closeCursor();
		
		return $res;
	}
	

	// Modifier un produit. 
	// $produit c'est les valeurs du nouveau client.
	// $numProduit c'est l'index en base du produit.
	public function ModifierProduit($produit,$numProduit){
		$this->reponse = $this->bdd->prepare("UPDATE produits SET 
														Des = :description, 
														PUHT = :prix WHERE NumProduit = ".$numProduit);
														
		$this->reponse->execute(array('description' => $produit->GetDescription(),
										'prix' => $produit->GetPrix()));
					
		$this->reponse->closeCursor();

	}

	// Effectuer une insertion de produit.
	public function InsererProduit($produit){
		$this->reponse = $this->bdd->prepare('INSERT INTO produits(Des,PUHT) 
												VALUES(:description,:puht)'
											);


		$this->reponse->execute(array('description' => $produit->GetDescription(),
										'puht' => $produit->GetPrix()));
					
		$this->reponse->closeCursor();
	}
	

	
	/* --  Gestion de l'achat d'un client  -- */

	// Affiche tous les produits pour le client (input type checkbox)
	public function AfficherProduitClient(){
		$this->reponse = $this->bdd->query("SELECT * FROM produits");
		
		/* 
		$id est utiliser pour lier le label(for="produit1") au radio (id="produit1"). Dans la boucle $id est incrémenté. produit1 produit2 etc...
		Il est également utilisé pour aficher le numero de la ligne du tableau du produit.
		*/
		$id = 1; 
		while($res = $this->reponse->fetch()){
			
			echo "<tr>
					<td>".$id."</td>
					<td>".htmlspecialchars($res["Des"])."</td>
					<td>".htmlspecialchars($res["PUHT"])."</td>
					<td>
							<input type='checkbox' value=".$res["NumProduit"]." name='numeroProduit[]' id='produits".$id."' />
							<input type='number' name='quantite[]' value='0' min='0' />
					</td>
				</tr>";	
				$id+=1;
		}
		$this->reponse->closeCursor();
	}
	
	// Insérer facture
	public function effectuerAchat($mailClient){
		$this->bdd->exec("INSERT INTO
                facture(NumClient,DateFacture)
                (
                    SELECT
                        NumClient,CURDATE()
                    FROM
                        client
                    WHERE
                        AdresseMail = '".$mailClient."'
				)");
	}
	
	// Insérer le detail d'une facture
	public function insererDetail($numeroProduit,$mailClient,$quantite){
		$this->reponse = $this->bdd->query("SELECT MAX(NumFacture) as numFacture from facture,client WHERE client.NumClient = facture.NumClient AND client.AdresseMail = '".$mailClient."'");

		$numeroFacture = $this->reponse->fetch();
		$this->reponse->closeCursor();
		
		$this->reponse = $this->bdd->prepare('
			INSERT INTO d_facture(NumFacture,NumProduit,Quantite)
			VALUES(:numFacture,:numProduit,:quantite)');


		$this->reponse->execute(array('numFacture' => $numeroFacture['numFacture'],
					'numProduit' => $numeroProduit,
					'quantite' => $quantite));
					
		$this->reponse->closeCursor();
	}

	
	
	
	
	/* -- Gestion des factures et détails de facture -- */
	
	// Lis toutes les factures.
	public function LireFactures(){
		$reponse = $this->bdd->query("SELECT * FROM facture");
		$res = $reponse->fetchAll();
		$reponse->closeCursor();   
		return $res;
	}
	
	// Lis le détail d'une facture.
	public function LireFacture($numFacture){
		$reponse = $this->bdd->query("SELECT produits.NumProduit,Des,PUHT,Quantite
											FROM produits
											INNER JOIN d_facture
											ON produits.NumProduit = d_facture.NumProduit
											INNER JOIN facture
											ON facture.NumFacture = d_facture.NumFacture
											WHERE facture.NumFacture = ".$numFacture);
											
		$res = $reponse->fetchAll();
		$reponse->closeCursor();   
		return $res;
	}
	
	// Lis le client d'une facture.
	public function LireClientFacture($numFacture){
		$reponse = $this->bdd->query("SELECT *,NumFacture,DateFacture
											FROM client
											INNER JOIN facture
											ON client.NumClient = facture.NumClient
											AND facture.NumFacture = ".$numFacture);
		$res = $reponse->fetch();
		$reponse->closeCursor();   
		return $res;
	}
	
	// Lire le total des achat
	// Lis le détail d'une facture.
	public function PrixTotal($numFacture){
		$reponse = $this->bdd->query("SELECT SUM(PUHT * d_facture.Quantite) as prix
											FROM produits
											INNER JOIN d_facture
											ON produits.NumProduit = d_facture.NumProduit
											INNER JOIN facture
											ON facture.NumFacture = d_facture.NumFacture
											WHERE facture.NumFacture = ".$numFacture);
											
		$res = $reponse->fetch();
		$reponse->closeCursor();   
		return $res;
	}
	
}

?>