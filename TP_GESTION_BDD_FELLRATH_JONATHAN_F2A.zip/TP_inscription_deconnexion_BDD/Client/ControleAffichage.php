<?php
// Controller Client.

	// Cennexion à la base de donnée
    try{
        $bdd = new PDO('mysql:host=localhost;dbname=FACTURE','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
    }catch (Exception $e){
        die('Erreur : ' . $e->getMessage());
    }
	
	// Séléction des clients
	$reponse = $bdd->query("SELECT * FROM client");
	$clients = $reponse->fetchAll();
	$reponse->closeCursor(); 

	$id = 1; // Gestion de l'id tableau 
	
?>
	<table class='tableauClient'>  
		<tr>
			<th style="padding:5px">ID</th>
			<th>NOM</th>
			<th>PRENOM</th>
			<th>MOT DE PASS</th>
			<th>MAIL</th>
			<th>ADRESSE</th>
			<th style='padding: 5px'>CODE POSTAL</th>
			<th>VILLE</th>
			<th>PAYS</th>
		</tr>
<?php
	foreach($clients as $client){
		echo "<tr>
				<td style='border-left:1px solid black;border-right:1px solid black'>".$id."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["NomClient"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["PrenomClient"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["MotDePasseClient"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["AdresseMail"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["AdresseClient"])."</td>
				<td style='border-right:1px solid black;'>".htmlspecialchars($client["Cp"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["VilleClient"])."</td>
				<td style='border-right:1px solid black'>".htmlspecialchars($client["PaysClient"])."</td>
				<td><form action='ModifierClient.php' method='POST'>
						<input type='radio' value=".$client['NumClient']." name='numeroClient' />
						<input type='submit' value ='Modifier' name='modifierClient' />
					</form>
					<form action='ControleSuppClient.php' method='POST'>
						<input type='radio' value=".$client["NumClient"]." name='numeroClient' />
						<input type='submit' value ='Supprimer' name='supprimerClient' />
					</form>
				</td>
			</tr>";	
		$id+=1;
	}
?>
		<tr>
			<td colspan = '9' style='border:1px solid black;text-align:center'>
				<form action='AjouterClient.php' method="POST">
					<input type='submit' value='Ajouter un client' name='ajouterClient' />
				</form>
			</td>
		</tr>
	</table>