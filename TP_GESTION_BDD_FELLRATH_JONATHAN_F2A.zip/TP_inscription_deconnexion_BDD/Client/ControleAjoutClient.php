<?php
	// Controller Client.
	if(isset($_POST['ajouterClient'])){

		// Cennexion à la base de donnée
		try{
			$bdd = new PDO('mysql:host=localhost;dbname=facture','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
		}catch (Exception $e){
			die('Erreur : ' . $e->getMessage());
		}
		
		// Verifie l'existence d'un profil. (Utiliser lors de l'inscription et lors de la modification d'un profil)
		// $mail c'est l'adresse mail à vérifier
		function VerifMail($mail,$base){
		
			$reponse = $base->prepare('SELECT AdresseMail FROM client WHERE AdresseMail = ?');
			
			$reponse->execute(array($mail));
			
			$res = $reponse->fetch();
			
			$reponse->closeCursor();
			
			return $res;
		}
		
		function InsererClient($base){
			$reponse = $base->prepare('
				INSERT INTO client(NomClient,PrenomClient,MotDePasseClient,AdresseMail,AdresseClient,Cp,VilleClient,PaysClient) 
				VALUES(:nom,:prenom,:mdp,:mail,:adresse,:cp,:ville,:pays)');


			$reponse->execute(array('nom' => $_POST['nom'],
						'prenom' => $_POST['prenom'],
						'mdp' => password_hash($_POST['mdp'],PASSWORD_DEFAULT),
						'mail' => $_POST['mail'],
						'adresse' => $_POST['adresse'],
						'cp' => $_POST['cp'],
						'ville' => $_POST['ville'],
						'pays' => $_POST['pays']));
						
			$reponse->closeCursor();
		}
		

		if (isset($_POST['nom']) and 
			isset($_POST['prenom']) and 
			isset($_POST['mdp']) and 
			isset($_POST['mail']) and 
			isset($_POST['adresse']) and 
			isset($_POST['ville']) and
			isset($_POST['pays']) and 
			isset($_POST['cp']) and
			!empty($_POST['nom']) and 
			!empty($_POST['prenom']) and 
			!empty($_POST['mail']) and 
			!empty($_POST['mdp']) and 
			!empty($_POST['adresse']) and 
			!empty($_POST['ville']) and 
			!empty($_POST['pays']) and 
			!empty($_POST['cp'])){ // Si les champs existe et ne sont pas vides

				// Si l'adresse mail validé par le formulaire existe déjà on l'indique
				if(!empty(VerifMail($_POST["mail"],$bdd))){

					header('Location: Client.php?erreur=1');
						
				}else{ // Sinon on insert le client
				
						InsererClient($bdd);
						header('Location: Client.php?ok=1');

				}
			}else{ //les champs sont mal remplis

				header('Location: Client.php?erreur=2');
		
			}
	}else{
		
		header('Location: Client.php');
		
	}
			
	
?>
