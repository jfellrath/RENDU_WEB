<?php
	session_start();
	
	if(isset($_GET['erreur']) and $_GET['erreur'] == 1){
	?>
		<script type="text/javascript">
   
			alert("Cette adresse mail existe déjà.");
   
		</script>
		<noscript>
			<p>
				<?php echo "Cette adresse mail existe déjà."; ?>
			</p>
		</noscript>
	<?php
	}else if(isset($_GET['erreur']) and $_GET['erreur'] == 2){
	?>
		<script type="text/javascript">
   
			alert("Merci de remplir tous les champs");
   
		</script>
		<noscript>
			<p>
				<?php echo "Merci de remplir tous les champs"; ?>
			</p>
		</noscript>
	<?php
	}else if(isset($_GET['erreur']) and $_GET['erreur'] == 3){
	?>
		<script type="text/javascript">
   
			alert("Merci de séléctionner un client.");
   
		</script>
		<noscript>
			<p>
				<?php echo "Merci de remplir tous les champs"; ?>
			</p>
		</noscript>
	<?php
	}else if(isset($_GET['ok']) and $_GET['ok'] == 1){
	?>
		<script type="text/javascript">
   
			alert("Le client a été ajouté avec succés !");
   
		</script>
		<noscript>
			<p>
				<?php echo "Le client a été ajouté avec succés !"; ?>
			</p>
		</noscript>
	<?php
	}else if(isset($_GET['ok']) and $_GET['ok'] == 2){
	?>
		<script type="text/javascript">
   
			alert("Le client a été mis à jour avec succés !");
   
		</script>
		<noscript>
			<p>
				<?php echo "Le client a été mis à jour avec succés !"; ?>
			</p>
		</noscript>
	<?php
	}else if(isset($_GET['ok']) and $_GET['ok'] == 3){
	?>
		<script type="text/javascript">
   
			alert("Le client a été supprimer avec succés !");
   
		</script>
		<noscript>
			<p>
				<?php echo "Le client a été supprimer avec succés !"; ?>
			</p>
		</noscript>
	<?php
	}
?>





<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8'/>
		<link type="text/css" media="screen" rel="stylesheet" href="styleClient.css" />
        <title>Gestion Client</title>
    </head>
    <body>
		<?php
			// Si la session de gérant existe
			if(isset($_SESSION["mail"])){
			?>
				<header>
					<table>
						<tr>
							<td>

								<!-- logo du site -->
								<img alt="logo" src="../mysql.png" />
								<a href="../index.php" />Retourner à l'acceuil</a>

							</td>
							<td>
							</td>
							<td>
								<!-- L'adresse mail de l'utilisateur -->
								<?php echo htmlspecialchars($_SESSION['mail']); ?>
								<!-- Lien vers deconnexion -->
								<br/><a href='../Controller/deconnexion.php'>Deconnexion</a>
							</td>
						</tr>
						<tr>
							<!-- Menu de navigation -->
							<td class='nav'>
								<a href="/">CLIENT</a>
							</td>
							<td class='nav'>
								<a href="../Facture/Facture.php">FACTURES</a>
							</td>
							<td class='nav'>
								<a href="../Produit/Produit.php">PRODUITS</a>
							</td>
						</tr>
					</table>
				</header>
				
			<?php
				include_once "ControleAffichage.php";
			}else{
				header('Location: ../index.php');
			}
		?>
	</body>
</html>