<?php
	session_start();
	
	if(isset($_SESSION['mail'])){
		
		if(isset($_POST['numeroClient'])){
			
			$_SESSION['numero'] = $_POST['numeroClient']; // Utiliser pour envoyer vers le controleModifClient
			
			// Cennexion à la base de donnée
			try{
				$bdd = new PDO('mysql:host=localhost;dbname=FACTURE','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			}catch (Exception $e){
				die('Erreur : ' . $e->getMessage());
			}
			

			// Lire un client séléctionné par son id
			$reponse = $bdd->query("SELECT * FROM client WHERE NumClient = ".$_POST['numeroClient']);
			$client = $reponse->fetch();
			$reponse->closeCursor(); 

		?>
		<!DOCTYPE html>
		<html>
			<head>
				<meta charset='utf-8'/>
				<link type="text/css" rel="stylesheet" href="styleClient.css" />
				<title>Modifier Client</title>
			</head>
			<body>
				<header>
					<table>
						<tr>
							<td>
								<!-- logo du site -->
								<img alt="logo" src="../mysql.png" />
								<a href="Client.php" />Retourner à la page précédente</a>
							</td>
							
							<td>
							
							</td>
							
							<td>
								<!-- L'adresse mail de l'utilisateur -->
								<?php echo htmlspecialchars($_SESSION['mail']); ?>
									<!-- Lien vers deconnexion -->
									<br/><a href='../Controller/deconnexion.php'>Deconnexion</a>
							</td>
						</tr>
					</table>
				</header>

				<nav>
					<h4>MODIFIER UN CLIENT</h4>
					<form action="ControleModifClient.php" method="POST">
						<!-- Nom  -->
						<label id="nom">Nom</label><br/>
						<!-- la variable client est créé dans le controller au moment ou on clique sur modifier. -->
						<input type="text" name="nom" value="<?php echo $client['NomClient'] ?>" /><br/><br/> 
						<!-- Prenom -->
						<label id="prenom">Prenom</label><br/>
						<input type="text" name="prenom" value="<?php echo $client['PrenomClient'] ?>"/><br/><br/>
						<!-- Adresse Mail -->
						<label id="mail">Adresse mail</label><br/>
						<input type="text" name="mail" value="<?php echo $client['AdresseMail'] ?>"/><br/><br/>
						<!-- Adrresse -->
						<label id="adresse">Adresse</label><br/>
						<input type="text" name="adresse" value="<?php echo $client['AdresseClient'] ?>"/><br/><br/>
						<!-- Code postal -->
						<label id="cp">Code postal</label><br/>
						<input type="text" name="cp" value="<?php echo $client['Cp'] ?>"/><br/><br/>
						<!-- Ville -->
						<label id="ville">Ville</label><br/>
						<input type="text" name="ville" value="<?php echo $client['VilleClient'] ?>"/><br/><br/>
						<!-- Pays -->
						<label id="pays">Pays</label><br/>
						<input type="text" name="pays" value="<?php echo $client['PaysClient'] ?>"/><br/><br/>
						<!-- Valider -->
						<input type="submit" value="Valider" name="modifierClient" />
					</form>
				</nav>		
			</body>
		</html>
		<?php
		}else{
			header('Location: Client.php?erreur=3');
		}
	}else{
		header('Location:../index.php');
	}
?>