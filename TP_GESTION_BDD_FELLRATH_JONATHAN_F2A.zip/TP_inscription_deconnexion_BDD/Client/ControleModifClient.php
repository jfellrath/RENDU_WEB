<?php
	session_start();
	
	// Controller Modif Client.
	if(isset($_POST['modifierClient'])){
		if(isset($_SESSION['numero'])){

			// Cennexion à la base de donnée
			try{
				$bdd = new PDO('mysql:host=localhost;dbname=facture','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			}catch (Exception $e){
				die('Erreur : ' . $e->getMessage());
			}
		
			function ModifierClient($numClient,$base){
				$reponse = $base->prepare("UPDATE client SET 
												NomClient = :nom, 
												PrenomClient = :prenom,
												AdresseMail = :mail,
												AdresseClient = :adresse,
												Cp = :cp,
												VilleClient = :ville,
												PaysClient = :pays 
												WHERE NumClient = ".$numClient);
																	
				$reponse->execute(array('nom' => $_POST['nom'],
							'prenom' => $_POST['prenom'],
							'mail' => $_POST['mail'],
							'adresse' => $_POST['adresse'],
							'cp' => $_POST['cp'],
							'ville' => $_POST['ville'],
							'pays' => $_POST['pays']));
								
				$reponse->closeCursor();

			}
			

			if (isset($_POST['nom']) and 
				isset($_POST['prenom']) and 
				isset($_POST['mail']) and 
				isset($_POST['adresse']) and 
				isset($_POST['ville']) and
				isset($_POST['pays']) and 
				isset($_POST['cp']) and
				!empty($_POST['nom']) and 
				!empty($_POST['prenom']) and 
				!empty($_POST['mail']) and 
				!empty($_POST['adresse']) and 
				!empty($_POST['ville']) and 
				!empty($_POST['pays']) and 
				!empty($_POST['cp'])){ // Si les champs existe et ne sont pas vides


					ModifierClient($_SESSION['numero'],$bdd);
					$_SESSION['numero'] = array();
					header('Location: Client.php?ok=2');

			}else{ //les champs sont mal remplis

				header('Location: Client.php?erreur=2');
			
			}
		}else{ // Aucun client selectionné
			header('Location: Client.php?erreur=3');
		}
	}else{
		// Si on arrive ici sans cliquer sur modifier client
		header('Location: Client.php');
		
	}
			
	
?>