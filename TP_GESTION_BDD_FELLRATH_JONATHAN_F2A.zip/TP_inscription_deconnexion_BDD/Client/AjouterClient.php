<?php
	session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8'/>
		<link type="text/css" rel="stylesheet" href="styleClient.css" />
        <title>Ajouter Client</title>
    </head>
    <body>
		<header>
			<table>
				<tr>
					<td>

						<!-- logo du site -->
						<img alt="logo" src="../mysql.png" />
						<a href="Client.php" />Retourner à la page précédente</a>

					</td>
					
					<td>
					
					</td>
					
					<td>
						<!-- L'adresse mail de l'utilisateur -->
						<?php echo htmlspecialchars($_SESSION['mail']); ?>
						<!-- Lien vers deconnexion -->
						<br/><a href='../Controller/deconnexion.php'>Deconnexion</a>
					</td>
				</tr>

			</table>
		</header>
		<nav>
			<h4>AJOUTER UN CLIENT</h4>
			<form action="ControleAjoutClient.php" method="POST">
				<!-- Nom  -->
				<label id="nom">Nom</label><br/>
				<input type="text" name="nom" /><br/><br/>
				<!-- Prenom -->
				<label id="prenom">Prenom</label><br/>
				<input type="text" name="prenom"/><br/><br/>
				<!-- Mot de passe -->
				<label id="mdp">Mot de passe</label><br/>
				<input type="password" name="mdp"/><br/><br/>
				<!-- Adresse Mail -->
				<label id="mail">Adresse mail</label><br/>
				<input type="text" name="mail"/><br/><br/>
				<!-- Adrresse -->
				<label id="adresse">Adresse</label><br/>
				<input type="text" name="adresse"/><br/><br/>
				<!-- Code postal -->
				<label id="cp">Code postal</label><br/>
				<input type="text" name="cp"/><br/><br/>
				<!-- Ville -->
				<label id="ville">Ville</label><br/>
				<input type="text" name="ville"/><br/><br/>
				<!-- Pays -->
				<label id="pays">Pays</label><br/>
				<input type="text" name="pays"/><br/><br/>
				<!-- Valider -->
				<input type="submit" value="Valider" name="ajouterClient" />
			</form>
		</nav>
	</body>
</html>