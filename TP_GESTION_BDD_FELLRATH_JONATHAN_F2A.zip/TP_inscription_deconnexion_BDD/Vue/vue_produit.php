<?php
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8'/>
        <title>Gestion des produits</title>
        <link rel="stylesheet" href="CSS/styleProduit.css?refresh=<?php echo rand(5,15) ?>" />
    </head>
    <body>
		<?php
			if(isset($_GET["refresh"])){
				?>
					<script type='text/javascript'>
					
						alert('Le produit a bien été mis à jour.');
						
					</script>
					
					<noscript>
						<p>
							<?php echo "Le produit a bien été mis à jour"; ?>
						</p>
					</noscript>
				<?php
			}					
		if(isset($_SESSION["mail"])){
		?>
			<header>
					<table style="margin:auto; text-align:center;">
						<tr>
							<td>

								<!-- logo du site -->
								<img alt="logo" src="../mysql.png" />
								<a style="color:black" href="../index.php" />Retourner à l'acceuil</a>
							</td>
							<td>
								
							</td>
							<td>
								<!-- L'adresse mail de l'utilisateur -->
								<?php echo htmlspecialchars($_SESSION['mail']); ?>
								<!-- Lien vers deconnexion -->
								<br/><a href='../Controller/deconnexion.php'>Deconnexion</a>
							</td>
						</tr>
						<tr>
							<!-- Menu de navigation -->
							<td class='nav'>
								<a href="vue_client.php">CLIENT</a>
							</td>
							<td class='nav'>
								<a href="vue_facture.php">FACTURES</a>
							</td>
							<td class='nav'>
								<a href="vue_produit.php">PRODUITS</a>
							</td>
						</tr>
					</table>
				</header>
		
			<table class='tableauProduit'>  
				<tr>
					<th>NumProduit</th>
					<th>Des</th>
					<th>PUHT</th>
				</tr>
				<?php
					include_once '../Controller/Produits.php';
				?>
				<tr>
					<td colspan = '3' style='text-align:center;;border:1px solid black'>
						<form action="vue_produit.php" method="POST">
							<input type="submit" value="Ajouter un produit" name="ajouterProduit" />
						</form>
					</td>
				</tr>
			</table>
			<?php
				if(isset($_POST["ajouterProduit"])){
				?>
					<nav>
						<h4>AJOUTER UN PRODUIT</h4>
						<form action="vue_produit.php" method="POST">
							<!-- Nom  -->
							<label id="nom">Description</label><br/>
							<input type="text" name="des" /><br/><br/>
							<!-- Prenom -->
							<label id="prenom">Prix unitaire hors taxe</label><br/>
							<input type="text" name="puht"/><br/><br/>

							<!-- Valider -->
							<input type="submit" value="Valider" name="AjouterProduit" />
						</form>
					</nav>
				<?php
				}else if(isset($_POST["numeroProduit"])){ // Valide par le bouton modifier
				?>	
					<nav>
						<h4>MODIFIER UN PRODUIT</h4>
						<form action="vue_produit.php" method="POST">
							<!-- description  -->
							<label for="des">Description</label><br/>
							<input type="text" name="des" id="des" value="<?php echo $produit['Des']; ?>" /><br/><br/>
							<!-- prix -->
							<label for="puht">Prix unitaire hors taxe</label><br/>
							<input type="text" name="puht" id="puht" value="<?php echo $produit['PUHT']; ?>"/><br/><br/>
							<!-- Valider -->
							<input type="submit" value="Valider" name="modifierProduit" />
						</form>
					</nav>
				<?php
				// Si on clique sur modifier mais qu'aucun produit n'est séléctionné.
				}else if(isset($_POST['modifier'])){
					?>
						<script type='text/javascript'>
					
							alert('Merci de séléctionner au moins un produit à modifier.');
						
						</script>
						
						<noscript>
							<p>
								<?php echo "Merci de séléctionner au moins un produit à modifier."; ?>
							</p>
						</noscript>
					<?php	
				}
		}else{
			header('Location: ../index.php');
		}
		
		?>
    </body>
</html>