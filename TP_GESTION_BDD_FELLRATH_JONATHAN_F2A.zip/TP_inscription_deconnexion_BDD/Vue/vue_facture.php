<?php
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8'/>
        <title>Gestion factures</title>
        <link rel="stylesheet" type="text/css" href="styleFacture.css" media="screen" />
		<link rel="stylesheet" type="text/css" href="imprimante.css" media="print" />
    </head>
    <body>
		<?php
			if(isset($_SESSION["mail"])){

			?>
				<header>
					<table style="margin:auto; text-align:center;">
						<tr>
							<td>

								<!-- logo du site -->
								<img alt="logo" src="../mysql.png" />
								<a style="color:black" href="../index.php">Retourner à l'acceuil</a>
							</td>
							<td>
							</td>
							<td>
								<!-- L'adresse mail de l'utilisateur -->
								<?php echo htmlspecialchars($_SESSION['mail']); ?>
								<!-- Lien vers deconnexion -->
								<br/><a href='../Controller/deconnexion.php'>Deconnexion</a>
							</td>
						</tr>
						<tr>
							<!-- Menu de navigation -->
							<td class='nav'>
								<a href="vue_client.php">CLIENT</a>
							</td>
							<td class='nav'>
								<a href="vue_facture.php">FACTURES</a>
							</td>
							<td class='nav'>
								<a href="vue_produit.php">PRODUITS</a>
							</td>
						</tr>
					</table>
				</header>

				<table class="tableauFacture">  
					<tr>
						<th>ID</th>
						<th>Numero de facture</th>
						<th>Date</th>
						<th>Numero de Client</th>
					</tr>
			<?php
				include_once '../Controller/Facture.php';
				
			}else{
				header('Location: ../index.php');
			}
		?>
		<p class='imprimer'>
			Pour imprimer la facture: 'Clique droit >> imprimer'
		</p>
    </body>
</html>