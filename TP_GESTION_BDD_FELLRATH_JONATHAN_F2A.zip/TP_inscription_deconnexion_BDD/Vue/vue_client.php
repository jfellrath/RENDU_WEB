<?php
	session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8'/>
		<link rel="stylesheet" href="CSS/client.css?refresh=<?php echo rand(5,15) ?>" />
        <title>Gestion Client</title>
    </head>
    <body>
		<?php
			// Si la session de gérant existe
			if(isset($_SESSION["mail"])){
				// Valider par le formulaire de modification.
				if(isset($_GET["refresh"])){
				?>
							<script type="text/javascript">
	   
								alert("La mise à jour du client à été effectué.");
	   
							</script>
							<noscript>
								<p>
									<?php echo "La mise à jour du client à été effectué."; ?>
								</p>
							</noscript>
				<?php
				}
				
				
				?>	
				<header>
					<table>
						<tr>
							<td>

								<!-- logo du site -->
								<img alt="logo" src="../mysql.png" />
								<a href="../index.php" />Retourner à l'acceuil</a>

							</td>
							<td>
							</td>
							<td>
								<!-- L'adresse mail de l'utilisateur -->
								<?php echo htmlspecialchars($_SESSION['mail']); ?>
								<!-- Lien vers deconnexion -->
								<br/><a href='../Controller/deconnexion.php'>Deconnexion</a>
							</td>
						</tr>
						<tr>
							<!-- Menu de navigation -->
							<td class='nav'>
								<a href="vue_client.php">CLIENT</a>
							</td>
							<td class='nav'>
								<a href="vue_facture.php">FACTURES</a>
							</td>
							<td class='nav'>
								<a href="vue_produit.php">PRODUITS</a>
							</td>
						</tr>
					</table>
				</header>
				<table class='tableauClient'>  
						<tr>
							<th style="padding:5px">ID</th>
							<th>NOM</th>
							<th>PRENOM</th>
							<th>MOT DE PASS</th>
							<th>MAIL</th>
							<th>ADRESSE</th>
							<th>CODE POSTAL</th>
							<th>VILLE</th>
							<th>PAYS</th>
						</tr>
						<?php
							include_once "../Controller/Client.php";
						?>
						<tr>
							<td colspan = '9' style='border:1px solid black;text-align:center'>
								<form action='vue_client.php' method="GET">
									<input type='submit' value='Ajouter un client' name='addClient' />
								</form>
							</td>
						</tr>
				</table>
				<?php
				if(isset($_GET["addClient"])){
				?>
					<nav>
						<h4>AJOUTER UN CLIENT</h4>
						<form action="vue_client.php" method="POST">
							<!-- Nom  -->
							<label id="nom">Nom</label><br/>
							<input type="text" name="nom" /><br/><br/>
							<!-- Prenom -->
							<label id="prenom">Prenom</label><br/>
							<input type="text" name="prenom"/><br/><br/>
							<!-- Mot de passe -->
							<label id="mdp">Mot de passe</label><br/>
							<input type="password" name="mdp"/><br/><br/>
							<!-- Adresse Mail -->
							<label id="mail">Adresse mail</label><br/>
							<input type="text" name="mail"/><br/><br/>
							<!-- Adrresse -->
							<label id="adresse">Adresse</label><br/>
							<input type="text" name="adresse"/><br/><br/>
							<!-- Code postal -->
							<label id="cp">Code postal</label><br/>
							<input type="text" name="cp"/><br/><br/>
							<!-- Ville -->
							<label id="ville">Ville</label><br/>
							<input type="text" name="ville"/><br/><br/>
							<!-- Pays -->
							<label id="pays">Pays</label><br/>
							<input type="text" name="pays"/><br/><br/>
							<!-- Valider -->
							<input type="submit" value="Valider" name="ajouterClient" />
						</form>
					</nav>
				<?php
				}if(isset($_POST["numeroClient"])){ // Valide par le bouton modifier créer dans le controller si une case radio est selectionné
				?>	
					<nav>
						<h4>MODIFIER UN CLIENT</h4>
						<form action="vue_client.php" method="POST">
							<!-- Nom  -->
							<label id="nom">Nom</label><br/>
							<!-- la variable client est créé dans le controller au moment ou on clique sur modifier. -->
							<input type="text" name="nom" value="<?php echo $client['NomClient'] ?>" /><br/><br/> 
							<!-- Prenom -->
							<label id="prenom">Prenom</label><br/>
							<input type="text" name="prenom" value="<?php echo $client['PrenomClient'] ?>"/><br/><br/>
							<!-- Adresse Mail -->
							<label id="mail">Adresse mail</label><br/>
							<input type="text" name="mail" value="<?php echo $client['AdresseMail'] ?>"/><br/><br/>
							<!-- Adrresse -->
							<label id="adresse">Adresse</label><br/>
							<input type="text" name="adresse" value="<?php echo $client['AdresseClient'] ?>"/><br/><br/>
							<!-- Code postal -->
							<label id="cp">Code postal</label><br/>
							<input type="text" name="cp" value="<?php echo $client['Cp'] ?>"/><br/><br/>
							<!-- Ville -->
							<label id="ville">Ville</label><br/>
							<input type="text" name="ville" value="<?php echo $client['VilleClient'] ?>"/><br/><br/>
							<!-- Pays -->
							<label id="pays">Pays</label><br/>
							<input type="text" name="pays" value="<?php echo $client['PaysClient'] ?>"/><br/><br/>
							<!-- Valider -->
							<input type="submit" value="Valider" name="modifierClient" />
						</form>
					</nav>
				<?php
				}else{
					// Si clique sur modifier sans selectionner un client.
					if(isset($_POST["modifier"])){
						?>
							<!-- Si javascript est activé -->
							<script type="text/javascript">
	   
								alert("Merci de séléctionner le client à modifier.");
	   
							</script>
							<!-- Si javascript est desactivé -->
							<noscript>
								<p>
									<?php echo "Merci de séléctionner le client à modifier."; ?>
								</p>
							</noscript>
						<?php
					}
				}
			}else{
				header('Location: ../index.php');
			}
		?>
	</body>
</html>
		



