<?php



class Produit {
	// donnees membres
	private $_idProduit;
	private $_DesProduit;
	private $_PUHT;

	
	
	public function __construct($id_Produit,$des_Produit,$PUHT){
		$this->_idProduit=$id_Produit;
		$this->_DesProduit=$des_Produit;
		$this->_PUHT=$PUHT;
	}
	
	public function __destruct() {}
	
	public function afficheProduit(){

		echo "Produit" . $this->_idProduit ."<br />Des: ".$this->_DesProduit."<br />Puht: ".$this->_PUHT;

	}
	
	
	
	//Mutateurs
	public function getIdProduit(){
		return $this->_idProduit;
	}
	public function getDesProduit(){
		return $this->_DesProduit;
	}
	public function getPUHTProduit(){
		return $this->_PUHT;
	}

	public function setIdProduit($midProduit){
		$this->_idProduit=$midProduit;
	}
	public function setDesProduit($mdesProduit){
		$this->_DesProduit=$mdesProduit;
	}
	public function setPUHTProduit($mPUHT){
		$this->_PUHT=$mPUHT;
	}
	
	



}


?>