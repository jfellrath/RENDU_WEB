<?php
include_once("Class_client.php");
include_once("Class_detail.php");
include_once("Class_produit.php");


	$client = new client(1, "ville", "cp", "tel", "email");
	$client->afficheClient();
	echo "<br/><br/>";
	$facture = new facture(1,"11/5/2017","cheque");
	$facture->afficherFacture();
	echo "<br/><br/>";
	$produit = new produit(1,"TV",99);
	$produit->afficheProduit();
	echo "<br/><br/>";
	$detail = new Quantite(1);
	$detail->addProduit($produit);
	
	$facture->AddClient($client);
	$facture->AddDFacture($detail);
	$client->AddFacture($facture);

	echo "<br /><br/>Le client de la facture<br/>";
	$facture->AfficherClient();


	echo "<br/>La facture du client<br/>";
	$client->AfficherFacture();

?>