<?php

class Quantite {
	// donnees membres
	private $_Quantite;
	private $produit;
	
	
	public function __construct($mquantite){
		$this->_Quantite=$mquantite;
		$produit = array();
	}
	
	public function __destruct() {}
	
	public function afficheQuantite(){
		echo '<br/>';
		echo $this->_Quantite;
		echo '<br/>';
	}
	
	
	
	//Mutateurs
	public function getQuantite(){
		return $this->_Quantite;
	}
	

	public function setQuantite($mquantite){
		$this->_Quantite=$mquantite;
	}
	
	public function AddProduit($produit){
		$this->produit[] = $produit;
	}
	
	public function AfficherProduit(){
		print_r($this->produit);
	}
	





}


?>