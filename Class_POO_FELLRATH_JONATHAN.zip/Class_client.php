<?php

include_once("Class_facture.php");

class client
{
	private $_ID;
	private $_Ville;
	private $_CP;
	private $_Tel;
	private $_Email;
	private $_facture;
	
	public function __construct($id, $ville, $cp, $tel, $email)
	{ 
		$this->_ID=$id;
		$this->_Ville=$ville;
		$this->_CP=$cp;
		$this->_Tel=$tel;
		$this->_Email=$email;
		$this->_facture = array();
	}
	
	public function __destruct(){}



	//Mutateurs
	// GET
	public function getID()
		{
			return $this->_ID;
		}
	public function getVILLE()
		{
			return $this->_Ville;
		}
	public function getCP()
		{
			return $this->_CP;
		}
	public function getTEL()
		{
			return $this->_Tel;
		}
	public function getEMAIL()
		{
			return $this->_Email;
		}
		
	public function GetFacture($index){
		return $this->_facture[$index];
	}
		
		
		
	//SET
	public function setID($id)
	{
		$this->_ID=$id;
	}
	public function setVILLE($ville)
	{
		$this->_y=$mY;
	}
	public function setCP($cp)
	{
		$this->_CP=$cp;
	}
	public function setTEL($tel)
	{
		$this->_TEL=$tel;
	}
	public function setEMAIL($email)
	{
		$this->_EMAIL=$email;
	}
	
	public function AddFacture($facture){
		$this->_facture[] = $facture;
	}
	
	public function AfficherFacture(){
		print_r($this->_facture);
	}


	public function afficheclient ()
	{
		echo 'client '.$this->_ID.'<br /> Ville : '.$this->_Ville.'<br/> CP : '.$this->_CP.'<br/>Tél : '.$this->_Tel.'<br/> Email : '.$this->_Email;
	}
}
?>