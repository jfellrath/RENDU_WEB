<?php



class Facture {
	// donnees membres
	private $_idFacture;
	private $_dateFacture;
	private $_modePaieFacture;
	
	private $client;
	private $dFacture;

	
	
	
	
	public function __construct($id_Facture,$date_Facture,$mode_PaieFacture){
		$this->_idFacture=$id_Facture;
		$this->_dateFacture=$date_Facture;
		$this->_modePaieFacture=$mode_PaieFacture;
		
		$this->client = array();
		$this->dFacture = array();
		
	}

	
	
	public function __destruct() {}

	
	
	
	//Mutateurs
	public function getIdFacture(){
		return $this->_idFacture;
	}
	public function getDateFacture(){
		return $this->_dateFacture;
	}
	public function getModePaieFacture(){
		return $this->_modePaieFacture;
	}
	
	public function GetClient($index){
		return $this->client[$index];
	}
	
	public function GetDFacture($index){
		return $this->dFacture[$index];
	}

	public function AfficherFacture(){
		echo "Facture1 ".$this->_idFacture.'<br /> Ville : '.$this->_dateFacture.'<br/> CP : '.$this->_modePaieFacture;
	}

	public function AfficherClient(){
		print_r($this->client);
	}
	
	
	public function setIdFacture($midFacture){
		$this->_idFacture=$midFacture;
	}
	public function setDateFacture($mdateFacture){
		$this->_dateFacture=$mdateFacture;
	}
	public function setModePaieFacture($mmodePaieFacture){
		$this->_modePaieFacture=$mmodePaieFacture;
	}
	

	public function AddClient($client){
		$this->client[] = $client;
	}
	
	public function AddDFacture($Quantite){
		$this->dFacture[] = $Quantite;
	}
	




}


?>